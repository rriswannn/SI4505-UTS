<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\RepairRecord;
use App\Models\Machine;


class RepairRecordController extends Controller
{
    /**
     * Display a listing of the repair records.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $repairRecords = RepairRecord::all();
        return view('repair_records', compact('repairRecords'));
    }

    /**
     * Show the form for creating a new repair record.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('repair_records.create');
    }

    /**
     * Store a newly created repair record in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate the request data
        $validator = Validator::make($request->all(), [
            'machine_id' => 'required|exists:machines,id',
            'repair_date' => 'required|date',
            'description' => 'required|string',
        ]);

        // If validation fails, return the errors
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Create a new repair record
        $repairRecord = RepairRecord::create($request->all());

        // Return a response indicating success
        return response()->json($repairRecord, 201);
        
    }
}
