<?php

namespace App\Http\Controllers;

use App\Models\MaintenanceSchedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class MaintenanceScheduleController extends Controller
{
    public function index()
    {
        $maintenanceSchedules = MaintenanceSchedule::all();
        return view('maintenance-schedules', compact('maintenanceSchedules'));
    }
    
    public function store(Request $request)
    {
        // Validasi input
        $validator = Validator::make($request->all(), [
            'machine_id' => 'nullable|exists:machines,id',
            'maintenance_date' => 'required|date',
            'description' => 'required|string',
        ]);
    
        // Jika validasi gagal
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
    
        // Buat maintenance schedule baru dengan data yang diberikan
        $maintenanceSchedule = new MaintenanceSchedule([
            'machine_id' => $request->input('machine_id'), // Tetapkan machine_id dari permintaan
            'maintenance_date' => $request->maintenance_date,
            'description' => $request->description,
        ]);
    
        // Simpan maintenance schedule ke dalam database
        $maintenanceSchedule->save();
           
        // Berikan respons JSON dengan kode status 201 (Created) dan data maintenance schedule yang baru dibuat
        return response()->json($maintenanceSchedule, 201);
    }

    public function create()
    {
        return view('maintenance_form'); 
    }
}
