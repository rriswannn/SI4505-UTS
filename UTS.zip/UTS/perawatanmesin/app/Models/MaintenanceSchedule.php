<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MaintenanceSchedule extends Model
{
    protected $fillable = ['machine_id', 'maintenance_date', 'description'];

    public function machine()
    {
        return $this->belongsTo(Machine::class);
    }
}
