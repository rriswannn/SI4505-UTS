<?php

namespace App\Models;
use App\Models\RepairRecord;
use Illuminate\Database\Eloquent\Model;

class RepairRecord extends Model
{
    protected $table = 'repair_records'; // Menentukan nama tabel

    protected $fillable = ['machine_id', 'repair_date', 'description'];

    public function machine()
    {
        return $this->belongsTo(Machine::class);
    }

    
}
