<?php

require_once __DIR__.'/../vendor/autoload.php';

(new Laravel\Lumen\Bootstrap\LoadEnvironmentVariables(
    dirname(__DIR__)
))->bootstrap();

date_default_timezone_set(env('APP_TIMEZONE', 'UTC'));

$app = new Laravel\Lumen\Application(
    dirname(__DIR__)
);

// Registrasi Fasade
$app->withFacades();

// Registrasi Eloquent ORM
$app->withEloquent();

// Konfigurasi Database
$app->configure('database');

// Registrasi Service Provider untuk Database
$app->register(\Illuminate\Database\DatabaseServiceProvider::class);

// Alias untuk koneksi database
$app->alias('db', \Illuminate\Database\MySqlConnection::class);

// Routes
$app->router->group([
    'namespace' => 'App\Http\Controllers',
], function ($router) {
    require __DIR__.'/../routes/web.php';
});

return $app;
