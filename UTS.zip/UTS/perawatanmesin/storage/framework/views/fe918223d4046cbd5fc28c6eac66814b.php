<!-- resources/views/repair_record_form.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Repair Record</title>
</head>
<body>
    <h1>Add Repair Record</h1>
    <form action="<?php echo e(url('/repair-records')); ?>" method="POST">
        <?php echo csrf_field(); ?> <!-- Laravel CSRF Protection -->
        
        <label for="machine_id">Machine ID:</label><br>
        <input type="number" id="machine_id" name="machine_id"><br><br>
        
        <label for="repair_date">Repair Date:</label><br>
        <input type="date" id="repair_date" name="repair_date"><br><br>
        
        <label for="description">Description:</label><br>
        <textarea id="description" name="description"></textarea><br><br>
        
        <button type="submit">Submit</button>
    </form>
</body>
</html>
<?php /**PATH /Users/rriswannnn/UTS/perawatanmesin/resources/views/repair_record_form.blade.php ENDPATH**/ ?>