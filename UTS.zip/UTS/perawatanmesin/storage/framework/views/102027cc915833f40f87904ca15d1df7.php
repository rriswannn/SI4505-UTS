<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Repair Record</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .ui.container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .ui.header {
            color: #007bff;
        }
        .ui.form .field label {
            color: #333;
            font-weight: bold;
        }
        .ui.form input[type="number"],
        .ui.form input[type="date"],
        .ui.form textarea {
            border-radius: 5px;
            border: 1px solid #ced4da;
            padding: 10px;
            width: 100%;
            margin-top: 5px;
        }
        .ui.form .field textarea {
            resize: none;
            min-height: 100px;
        }
        .ui.form .field input[type="submit"].ui.button.primary {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="ui container">
        <h1 class="ui header">Add Repair Record</h1>
        <form id="repairRecordForm" class="ui form">
            <div class="field">
                <label>Machine ID</label>
                <input type="number" name="machine_id" placeholder="Machine ID">
            </div>
            <div class="field">
                <label>Repair Date</label>
                <input type="date" name="repair_date">
            </div>
            <div class="field">
                <label>Description</label>
                <textarea name="description" placeholder="Description"></textarea>
            </div>
            <input type="submit" class="ui button primary" value="Submit">
        </form>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#repairRecordForm').submit(function (event) {
                event.preventDefault();
                var formData = $(this).serialize();
                $.ajax({
                    type: "POST",
                    url: "http://localhost:8000/repair-records",
                    data: formData,
                    success: function (response) {
                        alert("Repair record added successfully!");
                        $('#repairRecordForm')[0].reset();
                    },
                    error: function (error) {
                        alert("Failed to add repair record. Please try again.");
                    }
                });
            });
        });
    </script>
</body>
</html>
<?php /**PATH /Users/rriswannnn/UTS/perawatanmesin/resources/views/repair_records/create.blade.php ENDPATH**/ ?>