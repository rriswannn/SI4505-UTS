<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Machine;
use App\Models\MaintenanceSchedule;
use App\Models\RepairRecord;

class NewDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Memasukkan data dummy untuk tabel machines
        $batteryMachine = Machine::create([
            'name' => 'Mesin Produksi Baterai',
            'description' => 'Mesin canggih yang digunakan untuk memproduksi baterai berkualitas tinggi untuk motor listrik.',
        ]);

        $motorMachine = Machine::create([
            'name' => 'Mesin Perakitan Motor',
            'description' => 'Mesin otomatis yang melakukan perakitan komponen-komponen motor listrik secara efisien dan presisi.',
        ]);

        // Memasukkan data dummy untuk tabel maintenance_schedules
        MaintenanceSchedule::create([
            'machine_id' => $batteryMachine->id,
            'maintenance_date' => '2024-05-01',
            'description' => 'Jadwal perawatan untuk Mesin Produksi Baterai.',
        ]);

        MaintenanceSchedule::create([
            'machine_id' => $motorMachine->id,
            'maintenance_date' => '2024-05-02',
            'description' => 'Jadwal perawatan untuk Mesin Perakitan Motor.',
        ]);

        // Memasukkan data dummy untuk tabel repair_records
        RepairRecord::create([
            'machine_id' => $batteryMachine->id,
            'repair_date' => '2024-05-05',
            'description' => 'Catatan perbaikan untuk Mesin Produksi Baterai.',
        ]);

        RepairRecord::create([
            'machine_id' => $motorMachine->id,
            'repair_date' => '2024-05-06',
            'description' => 'Catatan perbaikan untuk Mesin Perakitan Motor.',
        ]);
    }
}
