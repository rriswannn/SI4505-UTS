<?php

use App\Http\Controllers\MaintenanceScheduleController;
use App\Http\Controllers\RepairRecordController;
use Laravel\Lumen\Routing\Router;

/** @var Router $router */

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$router->get('/maintenance-schedules', function () {
    return view('maintenance_schedules');
});



// Routes untuk Maintenance Schedule
$router->group(['prefix' => 'maintenance-schedules'], function () use ($router) {
    $router->get('/', 'MaintenanceScheduleController@index'); // Menampilkan index maintenance schedule
    $router->post('/', 'MaintenanceScheduleController@store'); // Menyimpan maintenance schedule
    $router->get('/create', 'MaintenanceScheduleController@create'); // Menampilkan form maintenance schedule
});

// Routes untuk Repair Record
$router->group(['prefix' => 'repair-records'], function () use ($router) {
    $router->post('/', 'RepairRecordController@store'); // Menyimpan repair record
    $router->get('/', 'RepairRecordController@index'); // Menampilkan index repair record
});

$router->get('/maintenance-schedules/create', 'MaintenanceScheduleController@create');

// Rute untuk menampilkan formulir
$router->post('/repair-records', 'RepairRecordController@store');
$router->get('/repair-records/create', 'RepairRecordController@create');




