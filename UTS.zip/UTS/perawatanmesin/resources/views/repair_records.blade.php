<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Repair Records</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            padding: 20px;
        }
        h1 {
            color: #007bff;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border-radius: 5px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        th {
            background-color: #007bff;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        tr:hover {
            background-color: #e2e6ea;
        }
    </style>
</head>
<body>
    <h1>Repair Records</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Machine ID</th>
                <th>Repair Date</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($repairRecords as $record)
            <tr>
                <td>{{ $record->id }}</td>
                <td>{{ $record->machine_id }}</td>
                <td>{{ $record->repair_date }}</td>
                <td>{{ $record->description }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
