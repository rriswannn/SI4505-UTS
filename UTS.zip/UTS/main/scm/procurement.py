from flask import Flask, request, jsonify
import MySQLdb

app = Flask(__name__)


# Koneksi ke database MySQL
db = MySQLdb.connect(host="sql6.freesqldatabase.com", user="sql6703019", passwd="Tl8TXFcI9m", db="sql6703019")
cursor = db.cursor()

# Fungsi untuk mendapatkan bahan baku pengadaan berdasarkan ID
def get_bahan_baku_pengadaan_by_id(bahan_id):
    cursor.execute("SELECT * FROM bahan_baku_pengadaan WHERE id = %s", (bahan_id,))
    bahan = cursor.fetchone()
    return bahan

# Endpoint untuk menampilkan semua bahan baku pengadaan
@app.route('/pengadaan/bahan_baku', methods=['GET'])
def get_all_bahan_baku():
    cursor.execute("SELECT * FROM bahan_baku_pengadaan")
    bahan_baku_pengadaan = cursor.fetchall()
    return jsonify(bahan_baku_pengadaan)

# Endpoint untuk menambahkan bahan baku pengadaan baru
@app.route('/pengadaan/bahan_baku', methods=['POST'])
def add_bahan_baku():
    data = request.json
    cursor.execute("INSERT INTO bahan_baku_pengadaan (nama, jumlah, harga_per_unit) VALUES (%s, %s, %s)",
                   (data['nama'], data['jumlah'], data['harga_per_unit']))
    db.commit()
    return jsonify({'message': 'Data bahan baku berhasil ditambahkan!'})

# Endpoint untuk mendapatkan bahan baku pengadaan berdasarkan ID
@app.route('/pengadaan/bahan_baku/<int:bahan_id>', methods=['GET'])
def get_bahan_baku_by_id(bahan_id):
    bahan = get_bahan_baku_pengadaan_by_id(bahan_id)
    if bahan:
        return jsonify(bahan)
    else:
        return jsonify({"message": "Bahan baku pengadaan tidak ditemukan"}), 404
    
    


if __name__ == '__main__':
    app.run(port=5007)
