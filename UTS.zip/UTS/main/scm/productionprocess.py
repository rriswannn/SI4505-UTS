from flask import Flask, request, jsonify
import MySQLdb

app = Flask(__name__)

# Koneksi ke database MySQL
db = MySQLdb.connect(host="sql6.freesqldatabase.com", user="sql6703019", passwd="Tl8TXFcI9m", db="sql6703019")
cursor = db.cursor()

# Fungsi untuk mendapatkan motor listrik berdasarkan ID
def get_motor_by_id(motor_id):
    cursor.execute("SELECT * FROM motor_listrik WHERE id = %s", (motor_id,))
    motor = cursor.fetchone()
    return motor

# Fungsi untuk melakukan pagination data
def paginate_data(data, page, per_page):
    start_index = (page - 1) * per_page
    end_index = start_index + per_page
    return data[start_index:end_index]

# Endpoint untuk menampilkan data motor listrik dengan pagination
@app.route('/produksi/motor_listrik', methods=['GET', 'POST'])
def produksi_motor_listrik():
    if request.method == 'GET':
        # Mendapatkan parameter query untuk pagination (halaman dan jumlah per halaman)
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)

        # Mengambil data dari database dengan pagination
        cursor.execute("SELECT * FROM motor_listrik")
        motor_list = cursor.fetchall()
        paginated_data = paginate_data(motor_list, page, per_page)
        return jsonify(paginated_data)

    elif request.method == 'POST':
        data = request.json
        cursor.execute("INSERT INTO motor_listrik (nama, warna, tahun_pembuatan, harga) VALUES (%s, %s, %s, %s)",
                       (data['nama'], data['warna'], data['tahun_pembuatan'], data['harga']))
        db.commit()
        return jsonify({'message': 'Data motor berhasil ditambahkan!'}), 201

# Endpoint untuk mendapatkan motor listrik berdasarkan ID
@app.route('/produksi/motor_listrik/<int:motor_id>', methods=['GET'])
def get_motor(motor_id):
    motor = get_motor_by_id(motor_id)
    if motor:
        return jsonify(motor)
    else:
        return jsonify({"message": "Motor tidak ditemukan"}), 404



if __name__ == '__main__':
    app.run(port=5008)
