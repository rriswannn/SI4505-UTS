from flask import Flask, request, jsonify
import MySQLdb

app = Flask(__name__)

# Koneksi ke database MySQL
db = MySQLdb.connect(host="sql6.freesqldatabase.com", user="sql6703019", passwd="Tl8TXFcI9m", db="sql6703019")
cursor = db.cursor()

# Fungsi untuk mendapatkan produk penyimpanan berdasarkan ID
def get_produk_penyimpanan_by_id(produk_id):
    cursor.execute("SELECT * FROM produk_penyimpanan WHERE id = %s", (produk_id,))
    prod = cursor.fetchone()
    return prod

# Endpoint untuk menampilkan semua produk penyimpanan
@app.route('/penyimpanan/produk', methods=['GET'])
def get_all_produk_penyimpanan():
    cursor.execute("SELECT * FROM produk_penyimpanan")
    produk_penyimpanan = cursor.fetchall()
    return jsonify(produk_penyimpanan)

# Endpoint untuk menambahkan produk penyimpanan baru
@app.route('/penyimpanan/produk', methods=['POST'])
def add_produk_penyimpanan():
    data = request.json
    cursor.execute("INSERT INTO produk_penyimpanan (nama, jumlah, lokasi_penyimpanan) VALUES (%s, %s, %s)",
                   (data['nama'], data['jumlah'], data['lokasi_penyimpanan']))
    db.commit()
    return jsonify({'message': 'Data produk berhasil ditambahkan!'}), 201

# Endpoint untuk mendapatkan produk penyimpanan berdasarkan ID
@app.route('/penyimpanan/produk/<int:produk_id>', methods=['GET'])
def get_produk_penyimpanan(produk_id):
    prod = get_produk_penyimpanan_by_id(produk_id)
    if prod:
        return jsonify(prod)
    else:
        return jsonify({"message": "Produk penyimpanan tidak ditemukan"}), 404
    


if __name__ == '__main__':
    app.run(port=5009)
