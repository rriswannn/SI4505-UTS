from flask import Flask, request, jsonify
import MySQLdb

app = Flask(__name__)


# Koneksi ke database MySQL
db = MySQLdb.connect(host="sql6.freesqldatabase.com", user="sql6703019", passwd="Tl8TXFcI9m", db="sql6703019")
cursor = db.cursor()

# Fungsi untuk mendapatkan produk distribusi berdasarkan ID
def get_produk_distribusi_by_id(produk_id):
    cursor.execute("SELECT * FROM produk_distribusi WHERE id = %s", (produk_id,))
    produk = cursor.fetchone()
    return produk

# Endpoint untuk menampilkan semua produk distribusi
@app.route('/distribusi/produk', methods=['GET'])
def get_all_produk_distribusi():
    cursor.execute("SELECT * FROM produk_distribusi")
    produk_distribusi = cursor.fetchall()
    return jsonify(produk_distribusi)

# Endpoint untuk menambahkan produk distribusi baru
@app.route('/distribusi/produk', methods=['POST'])
def add_produk_distribusi():
    data = request.json
    cursor.execute("INSERT INTO produk_distribusi (nama, jumlah, alamat_tujuan) VALUES (%s, %s, %s)",
                   (data['nama'], data['jumlah'], data['alamat_tujuan']))
    db.commit()
    return jsonify({'message': 'Data produk berhasil ditambahkan!'})

# Endpoint untuk mendapatkan produk distribusi berdasarkan ID
@app.route('/distribusi/produk/<int:produk_id>', methods=['GET'])
def get_produk_distribusi(produk_id):
    produk = get_produk_distribusi_by_id(produk_id)
    if produk:
        return jsonify(produk)
    else:
        return jsonify({"message": "Produk distribusi tidak ditemukan"}), 404


if __name__ == '__main__':
    app.run(port=5006)