from flask import Flask, render_template, request, jsonify, redirect
import requests
import subprocess
import threading

app = Flask(__name__)

# Fungsi untuk mengambil data produk dari layanan distribusi
def get_distribution_info():
    try:
        response = requests.get('http://localhost:5006/distribusi/produk') # SCM - Distribusi
        if response.status_code == 200:
            distribution_info = response.json()
            return distribution_info
        else:
            return None
    except Exception as e:
        print("Error fetching distribution info:", str(e))
        return None

# Fungsi untuk mengambil data produk dari layanan procurement
def get_procurement_info():
    try:
        response = requests.get('http://localhost:5007/pengadaan/bahan_baku') # SCM - Pengadaan
        if response.status_code == 200:
            procurement_info = response.json()
            return procurement_info
        else:
            return None
    except Exception as e:
        print("Error fetching procurement info:", str(e))
        return None

# Fungsi untuk mengambil data produk dari layanan production process
def get_productionprocess_info():
    try:
        response = requests.get('http://localhost:5008/produksi/motor_listrik') # SCM - Produksi
        if response.status_code == 200:
            productionprocess_info = response.json()
            return productionprocess_info
        else:
            return None
    except Exception as e:
        print("Error fetching production process info:", str(e))
        return None

# Fungsi untuk mengambil data produk dari layanan storage
def get_storage_info():
    try:
        response = requests.get('http://localhost:5009/penyimpanan/produk') # SCM - Penyimpanan
        if response.status_code == 200:
            storage_info = response.json()
            return storage_info
        else:
            return None
    except Exception as e:
        print("Error fetching storage info:", str(e))
        return None

# Fungsi untuk mengambil data maintenance schedule dari layanan Lumen
def get_maintenance_schedules():
    try:
        response = requests.get('http://localhost:8000/maintenance-schedules') # Maintenance
        if response.status_code == 200:
            maintenance_schedules = response.json()
            return maintenance_schedules
        else:
            return None
    except Exception as e:
        print("Error fetching maintenance schedules:", str(e))
        return None

# Fungsi untuk menyimpan maintenance schedule ke layanan Lumen
def create_maintenance_schedule(machine_id, maintenance_date, description):
    try:
        response = requests.post('http://localhost:8000/maintenance-schedules', json={
            'machine_id': machine_id,
            'maintenance_date': maintenance_date,
            'description': description
        }) # Maintenance
        if response.status_code == 201:
            return True
        else:
            return False
    except Exception as e:
        print("Error creating maintenance schedule:", str(e))
        return False

@app.route('/')
def index():
    # Redirect ke halaman index.html
    return redirect('/index')

@app.route('/index')
def show_index():
    return render_template('index.html')

@app.route('/supply_chain_management') # SCM
def supply_chain_management():
    distribution_info = get_distribution_info()
    procurement_info = get_procurement_info()
    productionprocess_info = get_productionprocess_info()
    storage_info = get_storage_info()
    
    if distribution_info is not None and procurement_info is not None and productionprocess_info is not None and storage_info is not None:
        return render_template('supply_chain_management.html', distribution_info=distribution_info, procurement_info=procurement_info, productionprocess_info=productionprocess_info, storage_info=storage_info)
    else:
        return jsonify({'error': 'Failed to fetch data from one or more services'}), 500

@app.route('/machine_maintenance', methods=['GET', 'POST']) # Maintenance
def machine_maintenance():
    if request.method == 'POST':
        # Ambil data dari formulir
        machine_id = request.form.get('machine_id')
        maintenance_date = request.form.get('maintenance_date')
        description = request.form.get('description')

        # Kirim data ke layanan Lumen untuk membuat maintenance schedule
        success = create_maintenance_schedule(machine_id, maintenance_date, description)
        if success:
            return jsonify({'message': 'Jadwal maintenance berhasil disimpan!'})
        else:
            return jsonify({'error': 'Gagal menyimpan jadwal maintenance'}), 500
    elif request.method == 'GET':
        # Ambil data maintenance schedule dari layanan Lumen
        maintenance_schedules = get_maintenance_schedules()
        if maintenance_schedules is not None:
            return render_template('maintenance_schedules.html', maintenance_schedules=maintenance_schedules) # Maintenance
        else:
            return jsonify({'error': 'Gagal mengambil data maintenance schedule'}), 500

if __name__ == '__main__':
    app.run(debug=True)


# Fungsi untuk menjalankan server Lumen dari dalam Flask
def run_lumen_server():
    try:
        subprocess.run(["php", "-S", "localhost:8000", "-t", "/Users/rriswannnn/UTS/perawatanmesin/public"], check=True)
    except subprocess.CalledProcessError as e:
        print("Error running Lumen server:", e)

# Panggil fungsi untuk menjalankan server Lumen saat aplikasi Flask dijalankan
if __name__ == '__main__':
    run_lumen_server()
    app.run(debug=True)


@app.route('/maintenance-schedules/create')
def show_maintenance_form():
    return render_template('maintenance_form.html')

if __name__ == '__main__':
    app.run(debug=True)

@app.route('/repair-records/create')
def show_repair_record_form():
    return render_template('repair_record_form.html')

if __name__ == '__main__':
    app.run(debug=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/maintenance_and_repair')
def maintenance_and_repair():
    return render_template('maintenance_and_repair.html')

if __name__ == '__main__':
    app.run(debug=True)
    