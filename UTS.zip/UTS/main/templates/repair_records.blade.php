<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Repair Records</title>
</head>
<body>
    <h1>Repair Records</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Machine ID</th>
                <th>Repair Date</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($repairRecords as $record)
            <tr>
                <td>{{ $record->id }}</td>
                <td>{{ $record->machine_id }}</td>
                <td>{{ $record->repair_date }}</td>
                <td>{{ $record->description }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
