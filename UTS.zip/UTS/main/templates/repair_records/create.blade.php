<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Repair Record</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
</head>
<body>
    <div class="ui container">
        <h1>Add Repair Record</h1>
        <form id="repairRecordForm" class="ui form">
            <div class="field">
                <label>Machine ID</label>
                <input type="number" name="machine_id" placeholder="Machine ID">
            </div>
            <div class="field">
                <label>Repair Date</label>
                <input type="date" name="repair_date">
            </div>
            <div class="field">
                <label>Description</label>
                <textarea name="description" placeholder="Description"></textarea>
            </div>
            <button class="ui button primary" type="submit">Submit</button>
        </form>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#repairRecordForm').submit(function (event) {
                event.preventDefault();
                var formData = $(this).serialize();
                $.ajax({
                    type: "POST",
                    url: "http://localhost:8000/repair-records",
                    data: formData,
                    success: function (response) {
                        alert("Repair record added successfully!");
                        $('#repairRecordForm')[0].reset();
                    },
                    error: function (error) {
                        alert("Failed to add repair record. Please try again.");
                    }
                });
            });
        });
    </script>
</body>
</html>
